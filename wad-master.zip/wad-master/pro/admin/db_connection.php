<?php
$con = mysqli_connect("localhost","root","","techbox.db");
if(!$con)
    die("Connection failed");